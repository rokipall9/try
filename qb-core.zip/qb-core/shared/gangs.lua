QBShared = QBShared or {}
-- Gangs
QBShared.Gangs = {
	['none'] = {
		label = 'No Gang',
		grades = {
            ['0'] = {
                name = 'Unaffiliated'
            },
        },
	},
	['hydra'] = {
		label = 'Hydra Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['chang'] = {
		label = 'Chang Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['abulaban'] = {
		label = 'ABU LABAN',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['lostmc'] = {
		label = 'LostMc',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
	['ballas'] = {
		label = 'Ballas',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
	['vagos'] = {
		label = 'Vagos',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
	['sod'] = {
		label = 'Sod',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
	['gsf'] = {
		label = 'GSF - Families',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['bloods'] = {
		label = 'Bloods Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},   
	['mdm'] = {
		label = 'The Mandem',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['seaside'] = {
		label = 'Seaside Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['rust'] = {
		label = 'Rust Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['ptd'] = {
		label = 'PTD Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['toc'] = {
		label = 'TOC Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['marabunta'] = {
		label = 'ESM - Marabunta',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['gulag'] = {
		label = 'Gulag Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['tnh'] = {
		label = 'TNH Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['stk'] = {
		label = 'STK Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
    ['st'] = {
		label = 'st Gang',
		grades = {
            ['0'] = {
                name = 'Gangster'
            },
			['1'] = {
                name = 'Solider'
            },
			['2'] = {
                name = 'Right Hand'
            },
			['3'] = {
                name = 'Boss',
				isboss = true
            },
        },
	},
}