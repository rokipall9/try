QBShared = QBShared or {}
QBShared.ForceJobDefaultDutyAtLogin = true -- true: Force duty state to jobdefaultDuty | false: set duty state from database last saved

QBShared.Jobs = {
    ['unemployed'] = {
        label = 'Civilian',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Freelancer', payment = 75 },
        },
    },
    ['gundealer'] = {
        label = 'Gun Dealer',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Dealer', payment = 1000 },
        },
    },
    ['gruppe'] = {
        label = 'Gruppe6',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Brinks Driver', payment = 500 },
        },
    },
    ['delivery'] = {
        label = 'Kevin Deliveries',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Delivery Driver', payment = 750 },
        },
    },
    ['catcafe'] = {
        label = 'Cat Cafe',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Trainee', payment = 400 },
            ['1'] = { name = 'Waiter/Waitress', payment = 500 },
            ['2'] = { name = 'Assistant Manager', payment = 700 },
            ['3'] = { name = 'Manager', payment = 900, isboss = true },
            ['4'] = { name = 'Owner', payment = 1100, isboss = true },
        },
    },
    ['taco'] = {
        label = 'Taco',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Seller', payment = 300 },
            ['1'] = { name = 'Experienced Seller', payment = 400 },
            ['2'] = { name = 'V.CEO', payment = 600, isboss = true },
            ['3'] = { name = 'CEO', payment = 1000, isboss = true },
        },
    },
    ['pawnstar'] = {
        label = 'Pawnstar',
        defaultDuty = true,
        offDutyPay = true,
        grades = {
            ['0'] = { name = 'Worker', payment = 400 },
            ['1'] = { name = 'V.CEO', payment = 600, isboss = true },
            ['2'] = { name = 'CEO', payment = 1000, isboss = true },
        },
    },
    ['burgershot'] = {
        label = 'Burgershot',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Trainee', payment = 200 },
            ['1'] = { name = 'Employee', payment = 400 },
            ['2'] = { name = 'Burger Flipper', payment = 600 },
            ['3'] = { name = 'Manager', payment = 800, isboss = true },
            ['4'] = { name = 'CEO', payment = 1000, isboss = true },
        },
    },
    ['mcdonalds'] = {
        label = 'McDonalds',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Worker', payment = 400 },
            ['1'] = { name = 'Vice Boss', payment = 800 },
            ['2'] = { name = 'Boss', payment = 1200, isboss = true },
        },
    },
    ['realestate'] = {
        label = 'Real Estate',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Recruit', payment = 50 },
            ['1'] = { name = 'House Sales', payment = 75 },
            ['2'] = { name = 'Business Sales', payment = 100 },
            ['3'] = { name = 'Broker', payment = 125 },
            ['4'] = { name = 'Manager', payment = 150, isboss = true },
        },
    },
    ['tuner'] = {
        label = 'Tuner',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Worker', payment = 400 },
            ['1'] = { name = 'Experienced Worker', payment = 800 },
            ['2'] = { name = 'V.CEO', payment = 900, isboss = true },
            ['3'] = { name = 'CEO', payment = 1500, isboss = true },
        },
    },
    ['vanilla'] = {
        label = 'Vanilla Unicorn',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Trainee', payment = 200 },
            ['1'] = { name = 'Employee', payment = 600 },
            ['2'] = { name = 'Management', payment = 1000, isboss = true },
        },
    },
    ['tequila'] = {
        label = 'Tequila Club',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Trainee', payment = 50 },
            ['1'] = { name = 'Employee', payment = 75 },
            ['2'] = { name = 'Management', payment = 100, isboss = true },
        },
    },
    ['whitewidow'] = {
        label = 'White Widow',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Worker', payment = 400 },
            ['1'] = { name = 'Employee', payment = 800 },
            ['2'] = { name = 'Management', payment = 1200, isboss = true },
        },
    },
    ['lawyer'] = {
        label = 'Law Firm',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Associate', payment = 1400 },
        },
    },
    ['garbage'] = {
        label = 'Garbage Collector',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Collector', payment = 300 },
        },
    },
    ['corrections'] = {
        label = 'Department Of Corrections',
        defaultDuty = true,
        offDutyPay = true,
        grades = {
            ['0'] = { name = 'Cadet', payment = 400 },
            ['1'] = { name = 'Officer', payment = 800 },
            ['2'] = { name = 'Senior Officer', payment = 1200 },
            ['3'] = { name = 'Corporal', payment = 1400 },
            ['4'] = { name = 'Sergeant', payment = 1800 },
            ['5'] = { name = 'Lieutenant', payment = 2200, isboss = true },
            ['6'] = { name = 'Captain', payment = 2400, isboss = true },
            ['7'] = { name = 'Deputy Warden', payment = 2800, isboss = true },
            ['8'] = { name = 'Warden', payment = 3200, isboss = true },
        },
    },
    ['ambulance'] = {
        label = 'EMS',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Recruit', payment = 700 },
            ['1'] = { name = 'EMT-Basic', payment = 850 },
            ['2'] = { name = 'Paramedic', payment = 1000 },
            ['3'] = { name = 'Doctor', payment = 1150 },
            ['4'] = { name = 'Lieutenant', payment = 1300 },
            ['5'] = { name = 'Station Commander', payment = 1450, isboss = true },
            ['6'] = { name = 'Asst.Chief', payment = 1650, isboss = true },
            ['7'] = { name = 'Chief', payment = 1750, isboss = true },
        },
    },
    ['police'] = {
        label = 'Police',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Cadet', payment = 400 },
            ['1'] = { name = 'Officer', payment = 600 },
            ['2'] = { name = 'Ranger', payment = 800 },
            ['3'] = { name = 'Deputy', payment = 1000 },
            ['4'] = { name = 'Trooper', payment = 1200 },
            ['5'] = { name = 'Private I', payment = 1400 },
            ['6'] = { name = 'Senior Officer', payment = 1600 },
            ['7'] = { name = 'Senior Deputy', payment = 1800 },
            ['8'] = { name = 'Senior Ranger', payment = 2100 },
            ['9'] = { name = 'Senior Trooper', payment = 2300 },
            ['10'] = { name = 'Private II', payment = 2500 },
            ['11'] = { name = 'Corporal', payment = 2700 },
            ['12'] = { name = 'Sergeant', payment = 2900 },
            ['13'] = { name = 'Lieutenant', payment = 3100 },
            ['14'] = { name = 'Undersheriff', payment = 3300, },
            ['15'] = { name = 'Sheriff', payment = 3500, },
            ['16'] = { name = 'Captain', payment = 3700, },
            ['17'] = { name = 'Commander', payment = 3900, isboss = true },
            ['18'] = { name = 'Assistant Chief', payment = 4100, isboss = true },
            ['19'] = { name = 'Chief of Police (C.O.P)', payment = 4300, isboss = true },
        },
    },
    ['government'] = {
        label = 'Government',
        defaultDuty = true,
        offDutyPay = true,
        grades = {
            ['0'] = { name = 'Judge', payment = 5000 },
        },
    },
}