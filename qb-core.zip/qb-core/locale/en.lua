local Translations = {
    error = {
        not_online = 'שחקן לא מחובר',
        wrong_format = 'Incorrect format',
        missing_args = 'Not every argument has been entered (x, y, z)',
        missing_args2 = 'All arguments must be filled out!',
        no_access = 'איו לך גישות',
        company_too_poor = 'Your employer is broke',
        item_not_exist = 'אין את האייטים הזה בשרת',
        too_heavy = 'אין מקום באינוונטורי'
    },
    success = {},
    info = {
        received_paycheck = 'קבילת תשלום בסך $%{value}',
        job_info = 'גוב: %{value} | דרגה: %{value2} | תפקיד: %{value3}',
        gang_info = 'גאנג: %{value} | דרגה: %{value2}',
        on_duty = 'אתה לא בתפקיד',
        off_duty = 'אתה בתפקיד'
    }
}

Lang = Locale:new({
    phrases = Translations,
    warnOnMissing = true
})
